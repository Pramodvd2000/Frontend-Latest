// import React from 'react'
// import ReactDOM from 'react-dom'

// import App from './App'

// import './index.css'

// ReactDOM.render(<App />)


import React from "react";
import App from './App'

function Calendar() {
    return (
        <App />
    );
}

export default Calendar;